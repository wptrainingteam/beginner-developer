=== WP Learn Plugin Security ===
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WordPress plugin to showcase plugin security for Learn WordPress Online Workshop

Switch to the feature/more-secure-plugin branch to see the updated version, with all the security fixes applied.
